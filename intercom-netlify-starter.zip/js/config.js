// Copy this file to config.js and set your Intercom APP ID
// You can find the App ID in Intercom: Settings → Messenger → Install → Code snippet
window.__INTERCOM_CONFIG__ = {
  APP_ID: "htawnd0o",
  // For secure mode (optional), implement a tiny server to sign a user_hash:
  // See: https://www.intercom.com/help/en/articles/183-enable-identity-verification-for-web
};
